use project;

DROP TABLE IF EXISTS Rating;
CREATE TABLE  Rating (Rating int, Satisfaction varchar(20));
INSERT INTO Rating(Rating,Satisfaction)
VALUES (1,'Poor'),(2,'Above Average'),(3,'Average'),(4,'Good'),(5,'Excellent');

/*Employee Count In Each Department */
select Department,count(*) as 'Number of employees'  from hr 
group by Department;


/*Percentage Of Attrition In Each Department */
with attrition as 
	(select Department,count(*) as 'Number_of_employees_left'  from hr 
	where Attrition = 'Yes'
	group by Department) ,

	Total_count as (select Department,count(*) as 'Number_of_employees'  from hr 
	group by Department)

select Department, round((Number_of_employees_left/Number_of_employees)*100,2) as 
'Percentage Of Attrition In Each Department'
from attrition a
join Total_count b
using(Department)
order by 2 desc;

/* Count Of Attrition Rate With Respect To Martial Status*/
with attrition as 
	(select Department,count(*) as 'Number_of_employees_left',MaritalStatus  from hr 
	where Attrition = 'Yes'
	group by Department) ,

	Total_count as (select Department,count(*) as 'Number_of_employees'  from hr 
	group by Department)
       
select MaritalStatus, round((Number_of_employees_left/Number_of_employees)*100,2) as 
'Percentage Of Attrition In Each Department'
from attrition a
join Total_count b
using(Department)
group by 1
order by 2 desc;      
       

/* Count of attrition with respect to age*/
select concat(20*floor(Age/20), '-', 20*floor(Age/20) + 20) as `Age Group`,
       count(*) as `No. Of Employees Left` from hr where Attrition = 'Yes' group by 1 order by Age;


/* Count of attrition with respect to age*/
with Income_Vs_Attrition as(select count(*) as 'Below_Avg_Income',(select count(*) from hr
    where MonthlyIncome < (select avg(MonthlyIncome) from hr) and (Attrition = 'Yes')) as 'Left_In_Below_Avg_Income_Group' from hr
	where MonthlyIncome < (select avg(MonthlyIncome) from hr))
   
select Below_Avg_Income as 'No. of employees with salary below average',(Below_Avg_Income/Left_In_Below_Avg_Income_Group) as '% Employees left in below average salary' from Income_Vs_Attrition;

/* Ratings of worklife balance*/
select WorkLifeBalance as 'Rating',Satisfaction,count(*) as 'No. of employees' from hr h
join Rating r
on h.WorkLifeBalance = r.Rating
group by WorkLifeBalance;

/* No. of employees left the oragnisation according to experience*/
select concat(5*floor(TotalWorkingYears/5), '-', 5*floor(TotalWorkingYears/5) + 5) as `Working Years Of Employees`,
       count(*) as `No. Of Employees Left` from hr where Attrition = 'Yes' group by 1 order by (5*floor(TotalWorkingYears/5));
       
       
/* No. of employees left the oragnisation per job role*/
select JobRole,count(*) as 'No. of employees' from hr
where Attrition = 'Yes' 
group by JobRole;


/* Nth Salary Using Stored Procedure*/
delimiter &&
drop procedure if exists nth_highest_salary;
create procedure nth_highest_salary(IN n int)
begin
select * from hr c
where (n-1) = (select count(*) from hr d where d.MonthlyIncome > c.MonthlyIncome);
end &&
delimiter ;
call nth_highest_salary(10);


/* Highest Salary In Each Department*/
select  EmployeeNumber,Department,MonthlyIncome,Attrition from (select hr.*,dense_rank() over(partition by department order by MonthlyIncome Desc ) as rnk
from hr) k
where rnk = 1;


/* Satisfaction Indices Of Employees Left*/
select avg(EnvironmentSatisfaction) as 'Avg. environment satisfaction among the employees left',
avg(RelationshipSatisfaction) as 'Avg. relationship satisfaction among the employees left',
avg(JobSatisfaction) as 'Avg. job satisfaction among the employees left'
 from hr where attrition = 'Yes'